import { Animatable } from 'framer'

const opacity = Animatable(1)

export default {
  opacity,
}
