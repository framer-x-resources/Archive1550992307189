import { animate } from 'framer'
import { log } from 'ruucm-util'

const pageHandle = index => {
  log('index', index)
}

export default pageHandle
