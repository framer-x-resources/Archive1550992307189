import { Data } from 'framer'

const currentPage = 0
const pageNum = 99

export default Data({
  currentPage,
  pageNum,
})
