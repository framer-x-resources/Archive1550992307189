import { Animatable } from 'framer'

const rotation = Animatable(0)

export default {
  rotation,
}
