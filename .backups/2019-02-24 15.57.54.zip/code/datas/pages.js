import { Data } from 'framer'

const currentPage = 2
const pageNum = 21

export default Data({
  currentPage,
  pageNum,
})
