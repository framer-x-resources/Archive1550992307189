import { Data } from 'framer'

const currentPage = 0
const pageNum = 21

export default Data({
  currentPage,
  pageNum,
})
