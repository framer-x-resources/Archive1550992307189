import { Data } from 'framer'

const playerState = 'stop'

export default Data({
  playerState,
})
