import { Animatable } from 'framer'

const bottom = Animatable(0)

export default {
  bottom,
}
