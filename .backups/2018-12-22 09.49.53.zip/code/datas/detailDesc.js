import { Animatable } from 'framer'

const top = Animatable(0)
const opacity = Animatable(0)

export default {
  top,
  opacity,
}
